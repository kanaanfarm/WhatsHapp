# ConnectChat Pro v6.7.3 — Build 6739

## Mobile navigation repair

- Settings now opens immediately from the bottom navigation.
- Workspace pages display above the mobile conversation list.
- Saved Messages opens when any part of its row, including the avatar, is tapped.
- ConnectChat AI no longer appears as a duplicate private-chat row.
- AI remains available from the dedicated AI navigation button.

No database migration is required for this update.

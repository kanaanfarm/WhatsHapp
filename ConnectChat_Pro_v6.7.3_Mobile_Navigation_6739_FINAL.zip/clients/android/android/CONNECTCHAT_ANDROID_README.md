# ConnectChat Pro Android v6.4.1

Open this folder directly in Android Studio.

## Run on a phone

1. Allow Android Studio to finish Gradle synchronization.
2. Connect an Android phone with Developer Options and USB debugging enabled,
   or create an Android emulator.
3. Select the device and press **Run**.

## Build a debug APK

In Windows Command Prompt from this folder:

```bat
gradlew.bat assembleDebug
```

The APK will be created under:

`app\build\outputs\apk\debug\app-debug.apk`

The application connects to:

`https://connectchat-pro-kanaan.onrender.com`

Application ID: `com.connectchat.pro`

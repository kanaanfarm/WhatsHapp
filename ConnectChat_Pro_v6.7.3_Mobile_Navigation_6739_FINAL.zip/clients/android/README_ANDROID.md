# ConnectChat Pro Android

This Capacitor project wraps the deployed ConnectChat Pro v6.4.1 application:

`https://connectchat-pro-kanaan.onrender.com`

## Requirements

- Android Studio
- Android SDK installed by Android Studio
- JDK 17 or the JDK bundled with Android Studio
- Node.js 22 or later

## First setup

```bash
npm install
npm run android:sync
npm run android:open
```

Android Studio can then run the application on an emulator or connected phone.

## Build files

Debug APK:

```bash
npm run android:debug:windows
```

Release App Bundle:

```bash
npm run android:release:windows
```

On macOS or Linux, use `android:debug` and `android:release` instead.

The release bundle must be signed with the owner's private upload key before
Google Play submission. Never commit or share the upload keystore or its
passwords.

## Server requirement

The Render environment variable `PUBLIC_ORIGIN` must remain:

`https://connectchat-pro-kanaan.onrender.com`

The mobile application requires Internet access because messages, calls, AI,
profiles and files use the deployed ConnectChat server and Supabase.
